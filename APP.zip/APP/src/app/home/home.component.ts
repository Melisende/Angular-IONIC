import { Component, OnInit } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { DomSanitizer } from '@angular/platform-browser';
//import { K, U } from 'win32-api'


@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css'],
})
export class HomeComponent implements OnInit {
  
  title = 'MySample';
  textValue;
  url_info;
  link;
  font_name;
  arr_fonts;
  arr_font;
  constructor(private sanitizer: DomSanitizer) {
    this.sanitizer = sanitizer;
  }

  ngOnInit() {
  }
  
  change_font(event) {
    this.url_info = this.textValue;
    this.link = this.textValue;

    this.arr_fonts = this.url_info.split("&", 1);
    this.arr_font = this.arr_fonts[0].split("=", 2);
    this.font_name = this.arr_font[1].replace("+", " ");
  }
  
  getFontCSS() {
    return this.sanitizer.bypassSecurityTrustResourceUrl(this.link);
  }


  onClick() {
    alert('load font from url:\n' +
        'http://galaxy.signage.me/fonts/Cookie.ttf\n' +
        'and apply it on the Label'
        );

    // there are like 3,000 diff fonts so:
    // fonts should NOT be embeded into the project.
    // this app is running remotely and there is no mouse or keyboard
    // loading new font should be completely transparent to the use
    // should not have any popup when new font is loading.
    // while app is running is can load diff fonts dynamically
    // all i need to see that you can load one font transparently with all the condition above
  }
}
